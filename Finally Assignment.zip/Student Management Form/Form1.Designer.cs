﻿namespace Student_Management_Form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Male = new System.Windows.Forms.RadioButton();
            this.Female = new System.Windows.Forms.RadioButton();
            this.Agelabel = new System.Windows.Forms.Label();
            this.StudentIDlabel = new System.Windows.Forms.Label();
            this.StudentNamelabel = new System.Windows.Forms.Label();
            this.IDtextBox = new System.Windows.Forms.TextBox();
            this.AgetextBox = new System.Windows.Forms.TextBox();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.CoursesList = new System.Windows.Forms.ListBox();
            this.Result = new System.Windows.Forms.Label();
            this.submid = new System.Windows.Forms.Button();
            this.ExtraBox = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.Male);
            this.groupBox1.Controls.Add(this.Female);
            this.groupBox1.Controls.Add(this.Agelabel);
            this.groupBox1.Controls.Add(this.StudentIDlabel);
            this.groupBox1.Controls.Add(this.StudentNamelabel);
            this.groupBox1.Controls.Add(this.IDtextBox);
            this.groupBox1.Controls.Add(this.AgetextBox);
            this.groupBox1.Controls.Add(this.NametextBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(24, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(508, 298);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Student Form";
            // 
            // Male
            // 
            this.Male.AutoSize = true;
            this.Male.Location = new System.Drawing.Point(406, 260);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(72, 24);
            this.Male.TabIndex = 4;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = true;
            // 
            // Female
            // 
            this.Female.AutoSize = true;
            this.Female.Location = new System.Drawing.Point(279, 260);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(93, 24);
            this.Female.TabIndex = 3;
            this.Female.TabStop = true;
            this.Female.Text = "Female";
            this.Female.UseVisualStyleBackColor = true;
            // 
            // Agelabel
            // 
            this.Agelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Agelabel.Location = new System.Drawing.Point(31, 182);
            this.Agelabel.Name = "Agelabel";
            this.Agelabel.Size = new System.Drawing.Size(182, 32);
            this.Agelabel.TabIndex = 1;
            this.Agelabel.Text = "Age";
            // 
            // StudentIDlabel
            // 
            this.StudentIDlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentIDlabel.Location = new System.Drawing.Point(31, 129);
            this.StudentIDlabel.Name = "StudentIDlabel";
            this.StudentIDlabel.Size = new System.Drawing.Size(182, 32);
            this.StudentIDlabel.TabIndex = 1;
            this.StudentIDlabel.Text = " Student ID";
            this.StudentIDlabel.Click += new System.EventHandler(this.StudentIDlabel_Click);
            // 
            // StudentNamelabel
            // 
            this.StudentNamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentNamelabel.Location = new System.Drawing.Point(31, 80);
            this.StudentNamelabel.Name = "StudentNamelabel";
            this.StudentNamelabel.Size = new System.Drawing.Size(182, 32);
            this.StudentNamelabel.TabIndex = 1;
            this.StudentNamelabel.Text = " Student Name";
            this.StudentNamelabel.Click += new System.EventHandler(this.StudentNamelabel_Click);
            // 
            // IDtextBox
            // 
            this.IDtextBox.Location = new System.Drawing.Point(279, 126);
            this.IDtextBox.Name = "IDtextBox";
            this.IDtextBox.Size = new System.Drawing.Size(211, 26);
            this.IDtextBox.TabIndex = 1;
            // 
            // AgetextBox
            // 
            this.AgetextBox.Location = new System.Drawing.Point(279, 179);
            this.AgetextBox.Name = "AgetextBox";
            this.AgetextBox.Size = new System.Drawing.Size(211, 26);
            this.AgetextBox.TabIndex = 2;
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(279, 77);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(211, 26);
            this.NametextBox.TabIndex = 0;
            // 
            // Clearbutton
            // 
            this.Clearbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Clearbutton.Location = new System.Drawing.Point(204, 453);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(118, 46);
            this.Clearbutton.TabIndex = 9;
            this.Clearbutton.Text = "&Clear";
            this.Clearbutton.UseVisualStyleBackColor = false;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Exitbutton.Location = new System.Drawing.Point(353, 453);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(118, 46);
            this.Exitbutton.TabIndex = 10;
            this.Exitbutton.Text = "&Exit";
            this.Exitbutton.UseVisualStyleBackColor = false;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // CoursesList
            // 
            this.CoursesList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoursesList.FormattingEnabled = true;
            this.CoursesList.ItemHeight = 25;
            this.CoursesList.Items.AddRange(new object[] {
            "Java",
            "C#",
            "Html"});
            this.CoursesList.Location = new System.Drawing.Point(24, 349);
            this.CoursesList.Name = "CoursesList";
            this.CoursesList.Size = new System.Drawing.Size(145, 79);
            this.CoursesList.TabIndex = 5;
            this.CoursesList.SelectedIndexChanged += new System.EventHandler(this.CoursesList_SelectedIndexChanged);
            // 
            // Result
            // 
            this.Result.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Result.Location = new System.Drawing.Point(60, 519);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(411, 155);
            this.Result.TabIndex = 8;
            this.Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // submid
            // 
            this.submid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.submid.Location = new System.Drawing.Point(60, 453);
            this.submid.Name = "submid";
            this.submid.Size = new System.Drawing.Size(122, 46);
            this.submid.TabIndex = 7;
            this.submid.Text = "&Submid";
            this.submid.UseVisualStyleBackColor = false;
            this.submid.Click += new System.EventHandler(this.Submidbutton_Click);
            // 
            // ExtraBox
            // 
            this.ExtraBox.BackColor = System.Drawing.SystemColors.Control;
            this.ExtraBox.Location = new System.Drawing.Point(193, 384);
            this.ExtraBox.Name = "ExtraBox";
            this.ExtraBox.Size = new System.Drawing.Size(185, 24);
            this.ExtraBox.TabIndex = 6;
            this.ExtraBox.Text = "Extra_curricular";
            this.ExtraBox.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.groupBox1);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.ExtraBox);
            this.groupBox2.Controls.Add(this.Result);
            this.groupBox2.Controls.Add(this.CoursesList);
            this.groupBox2.Controls.Add(this.submid);
            this.groupBox2.Controls.Add(this.Clearbutton);
            this.groupBox2.Controls.Add(this.Exitbutton);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(57, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(894, 711);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Student Management";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Student_Management_Form.Properties.Resources.RTGEkrogc;
            this.pictureBox1.Location = new System.Drawing.Point(616, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(251, 208);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1397, 751);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Label StudentIDlabel;
        private System.Windows.Forms.Label StudentNamelabel;
        private System.Windows.Forms.TextBox AgetextBox;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.TextBox IDtextBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Agelabel;
        private System.Windows.Forms.ListBox CoursesList;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.Button submid;
        private System.Windows.Forms.CheckBox ExtraBox;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

